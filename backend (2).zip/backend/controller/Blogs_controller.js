import Blogs from "../modal/Blogs";
export const getAllBlogs = async (req, res, next) => {
	let blogs;
	try{
		blogs=await Blogs.find();
	}
	catch(err){
		
	return console.log(err);}
	if(!blogs){
		return res.status(404).json({message:"No Blogs found"})
	}
	return res.status(200).json({blogs})
}

export const addBlogs = async (req, res, next) => {
	 const { title, desc,image, user} = req.body;
	  const blog = new Blogs({
			title,
			desc,
			image,
			user,
  });
  try {
    await blog.save();
  } catch (err) {
    return console.log(err);
  }
  return res.status(200).json({ blog });
  // export default getAlluser;
};

export const updateBlogs = async (req, res, next) => {
	const blogId=req.params.id;
	const { title, desc,image} = req.body;
	let blog;
	try{
	blog =await Blogs.findByIdAndUpdate(blogId,{
		title,desc,image
	})
	}catch(err){
		return console.log(err);
	}
	if(!blog)
	{
		return res.status(500).json({message:"Upage error"});
		
	}
	return res.status(200).json({message:"success fully Update"});
	 
}