import React from "react";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import { useNavigate } from "react-router-dom";

function BlogPre({ title, desc, user, image, b_id }) {
  const navigate = useNavigate();
  const handleEdit = () => {
    navigate(`/editblog/:${b_id}`);
  };
  const handleDelete = () => {};
  return (
    <div style={{ display: "flex", margin: "12px 10rem" }}>
      <Card style={{ width: "100%" }}>
        {/* {isUser && ( */}
        <>
          <div className="row">
            <div className="col-10"></div>
            <div className="col-2 row">
              <div className="col-6">
                <button
                  className="btn btn-info"
                  style={{ width: "4rem" }}
                  onClick={handleEdit}
                >
                  Edit
                </button>
              </div>
              <div className="col-6">
                <button
                  className="btn btn-danger"
                  style={{ width: "5rem" }}
                  onClick={handleDelete}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </>
        {/* )} */}
        <Card.Img variant="top" src={image} style={{ height: "25rem" }} />
        <Card.Body>
          <Card.Title>{title}</Card.Title>
          <Card.Text>{desc}</Card.Text>
          <span>{user}</span>
        </Card.Body>
      </Card>
    </div>
  );
}

export default BlogPre;
