import React from "react";
import {
  BrowserRouter as Router,
  NavLink,
  Link,
  Route,
  Routes,
  BrowserRouter,
} from "react-router-dom";
import AddBlogs from "./AddBlogs";
import Blogs from "./Blogs";
import EditBlogs from "./EditBlogs";
import Header from "./Header";
import { Home } from "./Home";
import { Login } from "./Login";
function Mainpage() {
  return (
    <div className="">
      <BrowserRouter>
        <Header style={{ position: "fixed" }} />
        <Routes>
          <Route index element={<Home />} />
          <Route path="login" element={<Login />} />
          <Route path="blogs" element={<Blogs />} />
          <Route path="addblog" element={<AddBlogs />} />
          <Route path="editblog" element={<EditBlogs />} />
          {/*  />
          <Route path="contact" element={<Contact />} />
          <Route path="about" element={<About />} /> */}

          {/* <NavLink to="/login">Go to </NavLink> */}
        </Routes>
        <br />
        {/* <Footer /> */}
      </BrowserRouter>
    </div>
  );
}

export default Mainpage;
