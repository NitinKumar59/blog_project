import React from "react";

export const Home = () => {
  return (
    <div>Home
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />Home
      
    </div>
  );
};
