import axios from "axios";
import React, { useEffect, useState } from "react";
import BlogPre from "./BlogPre";

function Alluser() {
  const [blog, setBlogs] = useState();
  const id = localStorage.getItem("userId");
  const sendRequest = async () => {
    const res = await axios
      .get(`http://localhost:5000/user/${id}`)
      .catch((err) => console.log(err));
    const data = await res.data;
    return data;
  };
  useEffect(() => {
    sendRequest().then((data) => setBlogs(data.blog.blogs));
  }, []);
  return (
    <div>
      {blogs &&
        blogs.map((blog, index) => (
          <BlogPre
            key={index}
            isUser={true}
            title={blog.title}
            desc={blog.desc}
            user={blog.user}
            image={blog.image}
          />
        ))}
    </div>
  );
}

export default Alluser;
