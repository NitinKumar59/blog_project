import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import {
  BrowserRouter as Router,
  NavLink,
  Link,
  Route,
  Routes,
  BrowserRouter,
} from "react-router-dom";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { authActions } from "./app/store";
function Header() {
  const dispatch = useDispatch();
  const isLoggedIn = useSelector((state) => state.isLoggedIn);
  const [tabValue, setTabValue] = useState();
  return (
    <Navbar bg="secondary" expand="lg">
      <Container>
        <Navbar.Brand href="#home" className="text-warning">
          <strong>Blogs.Com</strong>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto collapse navbar-collapse">
            <ul className="head navbar-nav me-auto mb-2 mb-lg-0 ul-li-nav">
              <li className="nav-item">
                <NavLink className="navlinknav" to="/">
                  Home
                </NavLink>

                {/* <a className="nav-link active" aria-current="page" href="#">
                    Home
                  </a> */}
              </li>
              <li className="nav-item">
                <NavLink className="navlinknav" to="/blogs">
                  Blogs
                </NavLink>
              </li>
              {isLoggedIn && (
                <>
                  <li className="nav-item">
                    <NavLink className="navlinknav" to="/addblog">
                      Add Blogs
                    </NavLink>
                  </li>
                </>
              )}
              <li className="nav-item">
                <NavLink className="navlinknav" to="/contact">
                  {" "}
                  Contact Us
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="navlinknav" to="/about">
                  About Us
                </NavLink>
              </li>
            </ul>
            <ul className="head navbar-nav   mb-lg-0 ul-li-nav">
              {" "}
              {!isLoggedIn && (
                <>
                  <li className="nav-item">
                    <NavLink
                      className=" btn btn-success navlinknav"
                      to="/login"
                    >
                      Login
                    </NavLink>
                  </li>
                  <li className="nav-item">
                    <NavLink
                      className="btn btn-primary navlinknav"
                      to="/signup"
                    >
                      {" "}
                      Signup
                    </NavLink>
                  </li>
                </>
              )}
              {isLoggedIn && (
                <>
                  <li className="nav-item">
                    <NavLink
                      onClick={() => dispatch(authActions.logout())}
                      className="btn btn-danger navlinknav"
                      to="/signup"
                    >
                      {" "}
                      LogOut
                    </NavLink>
                  </li>
                </>
              )}
            </ul>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;
