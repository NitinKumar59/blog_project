import axios from "axios";
import React, { useState } from "react";
import { useParams } from "react-router-dom";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

function EditBlogs() {
  const id = useParams().b_id;
  console.log(id);
  const [inputs, setInputs] = useState({
    name: "",
    email: "",
    password: "",
  });
  const handlechange = (e) => {
    setInputs((preState) => ({
      ...preState,
      [e.target.name]: e.target.value,
    }));
  };
  const fetchDetails = async () => {
    const res = await axios.put(`http://localhost:5000/update/${id}`, {
      title: inputs.title,
      desc: inputs.desc,
      image: inputs.image,
    });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(inputs);
    fetchDetails().then((data) => console.log(data));
  };
  return (
    <div
      className="row"
      style={{ padding: "2rem 0px", justifyContent: "center" }}
    >
      <div className="col-lg-3 col-md-2"></div>
      <div className=" bg-light p-4 col-lg-6 col-md-8">
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <div align="center">
              <h2>Edit Blogs</h2>
            </div>
            <Form.Label>Blog Title</Form.Label>
            <Form.Control
              name="title"
              type="text"
              placeholder="Enter Blog Title"
              onChange={handlechange}
              values={inputs.title}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Discription</Form.Label>
            <Form.Control
              name="desc"
              type="text"
              placeholder="Enter Blog Description "
              onChange={handlechange}
              values={inputs.desc}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Image Url</Form.Label>
            <Form.Control
              name="image"
              onChange={handlechange}
              values={inputs.image}
              type="text"
              placeholder="Image Url"
            />
          </Form.Group>

          {/* <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group> */}
          <Button variant="primary" type="submit">
            Submit
          </Button>
        </Form>
      </div>
      <div className="col-lg-3 col-md-2"></div>
    </div>
  );
}

export default EditBlogs;
