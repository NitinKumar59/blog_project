import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import axios from "axios";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { authActions } from "./app/store";

export function Login() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [inputs, setInputs] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [isSignup, setSignup] = useState(false);
  const handlechange = (e) => {
    setInputs((preState) => ({
      ...preState,
      [e.target.name]: e.target.value,
    }));
  };
  const sendRequest = async (type = "login") => {
    const res = await axios
      .post(`http://localhost:5000/${type}`, {
        name: inputs.name,
        email: inputs.email,
        password: inputs.password,
      })
      .catch((err) => console.log(err));
    const data = await res.data;
    return data;
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(inputs);
    if (isSignup) {
      sendRequest("signup")
        .then((data) => localStorage.setItem("user", data.user._id))
        .then(() => dispatch(authActions.login()))
        .then(() => navigate("/"))
        .then((data) => console.log(data));
    } else {
      sendRequest()
        .then((data) => localStorage.setItem("user", data.user._id))
        .then(() => dispatch(authActions.login()))
        .then(() => navigate("/"))
        .then((data) => console.log(data));
    }
  };
  return (
    <div
      className="row"
      style={{ padding: "6rem 0px", justifyContent: "center" }}
    >
      <div className="col-lg-4 col-md-4"></div>
      <div className=" bg-light p-4 col-lg-4 col-md-4">
        <Form onSubmit={handleSubmit}>
          <div>
            <span
              marginTop={"2px"}
              onClick={() => setSignup(!isSignup)}
              variant="conteined"
              sx={{ borderRadius: 3, background: "red" }}
              className="btn btn-light form-control"
            >
              Change To {isSignup ? "Login" : "Signup"}
            </span>
          </div>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            {isSignup && (
              <>
                <Form.Label>Name</Form.Label>{" "}
                <Form.Control
                  name="name"
                  onChange={handlechange}
                  margin="normal"
                  placeholder="Enter Name"
                  autoComplete="off"
                  values={inputs.name}
                />
              </>
            )}
          </Form.Group>{" "}
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Email address</Form.Label>
            <Form.Control
              type="email"
              name="email"
              onChange={handlechange}
              values={inputs.email}
              placeholder="Enter email"
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              name="password"
              onChange={handlechange}
              placeholder="Password"
              values={inputs.password}
            />
          </Form.Group>
          <Button className="form-control" variant="primary" type="submit">
            Submit
          </Button>
        </Form>
      </div>
      <div className="col-lg-4 col-md-4"></div>
    </div>
  );
}

// export default Login;
