import React, { useEffect, useState } from "react";
import axios from "axios";
import BlogPre from "./BlogPre";
function Blogs() {
  const [blogs, setBlogs] = useState();
  const sendRequest = async () => {
    const res = await axios
      .get("http://localhost:5000/blogs")
      .catch((err) => console.log(err));
    const data = await res.data;
    return data;
  };
  useEffect(() => {
    sendRequest().then((data) => setBlogs(data.blogs));
  }, []);
  console.log(blogs);
  return (
    <div>
      {blogs &&
        blogs.map((blog, index) => (
          <BlogPre
            b_id={blog._id}
            title={blog.title}
            desc={blog.desc}
            user={blog.user}
            image={blog.image}
          />
        ))}
    </div>
  );
}

export default Blogs;
