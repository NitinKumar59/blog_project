import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import axios from "axios";
import { useState } from "react";

function AddBlogs() {
  const [inputs, setInputs] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [isSignup, setSignup] = useState(false);
  const handlechange = (e) => {
    setInputs((preState) => ({
      ...preState,
      [e.target.name]: e.target.value,
    }));
  };
  const sendRequest = async (type = "login") => {
    const res = await axios
      .post(`http://localhost:5000/addblog`, {
        title: inputs.title,
        desc: inputs.desc,
        image: inputs.image,
        user: localStorage.getItem("user"),
      })
      .catch((err) => console.log(err));
    const data = await res.data;
    return data;
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(inputs);
    sendRequest().then((data) => console.log(data));
  };

  return (
    <div
      className="row"
      style={{ padding: "2rem 0px", justifyContent: "center" }}
    >
      <div className="col-lg-3 col-md-2"></div>
      <div className=" bg-light p-4 col-lg-6 col-md-8">
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Blog Title</Form.Label>
            <Form.Control
              name="title"
              type="text"
              placeholder="Enter Blog Title"
              onChange={handlechange}
              values={inputs.title}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Discription</Form.Label>
            <Form.Control
              name="desc"
              type="text"
              placeholder="Enter Blog Description "
              onChange={handlechange}
              values={inputs.desc}
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <Form.Label>Image Url</Form.Label>
            <Form.Control
              name="image"
              onChange={handlechange}
              values={inputs.image}
              type="text"
              placeholder="Image Url"
            />
          </Form.Group>

          {/* <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group> */}
          <Button variant="primary" type="submit">
            Submit
          </Button>
        </Form>
      </div>
      <div className="col-lg-3 col-md-2"></div>
    </div>
  );
}

export default AddBlogs;
